
async function getKeyArray(key) {
    const result = await chrome.storage.local.get(key);
    let last_key = undefined;
    let real_result = result[key];
    if (Array.isArray(real_result)) {
        if (real_result.length == 0) {
            real_result = undefined;
        } else {
            last_key = real_result[real_result.length - 1];
        }
    }
    return {result: last_key, all: real_result};
}

async function check_migration() {
    let prev_version = (await chrome.storage.local.get("storageVersion")).storageVersion;
    if (prev_version == undefined) {
        prev_version = "0.0";
    }
    const current_version = chrome.runtime.getManifest().version;
    if (current_version != prev_version) {
        // Need to migrate.
        let old_data = await chrome.storage.local.get();
        if (prev_version < "0.2") {
            console.log("Migrating from " + prev_version + "to 0.2");
            let new_data = {};
            for (let [key, value] of Object.entries(old_data)) {
                if (key.startsWith("pubRsa_") || key == "publicRsaKey" || key == "privateRsaKey") {
                    if (typeof(value) == "string") {
                        value = [value];
                    } else if (value == undefined || value == null) {
                        value = [];
                    }
                }
                new_data[key] = value;
            }
            prev_version = "0.2";
            old_data = new_data;
        }
        if (prev_version < current_version) {
            // No more changes
            prev_version = current_version;
        }
        old_data.storageVersion = current_version;
        chrome.storage.local.set(old_data);
    }
}
async function serviceMessage(request) {
    await check_migration();
    switch (request.action) {
        case "get_public_rsa_key":
            return await getKeyArray("publicRsaKey");
        case "get_private_rsa_key":
            return await getKeyArray("privateRsaKey");
        case "get_someones_rsa_key": {
            const storageKey = "pubRsa_" + request.chatId;
            return await getKeyArray(storageKey);
        }
        case "add_someones_rsa_key": {
            const keyForStorage = "pubRsa_" + request.chatId;
            const result = await chrome.storage.local.get(keyForStorage);
            let array_keys = result[keyForStorage];
            if (array_keys == undefined) {
                array_keys = [];
            }
            const index = array_keys.indexOf(request.value);
            if (index != -1) {
                array_keys.splice(index, 1);
            }
            array_keys.push(request.value);
            await chrome.storage.local.set({
                [keyForStorage]: array_keys
            });
            return true;
        }
        case "add_rsa_key": {
            let pubKeys = await chrome.storage.local.get("publicRsaKey");
            let privKeys = await chrome.storage.local.get("privateRsaKey");
            pubKeys = (pubKeys == undefined || pubKeys.publicRsaKey == undefined) ? [] : pubKeys.publicRsaKey;
            privKeys = (privKeys == undefined || privKeys.privateRsaKey == undefined) ? [] : privKeys.privateRsaKey;
            if (privKeys.length != pubKeys.length) {
                throw new Error(
                    "Number of public keys and private are different. What the hell???"
                );
            }
            const index = pubKeys.indexOf(request.publicRsaKey);
            if (index != -1) {
                if (privKeys[index] != request.privateRsaKey) {
                    throw new Error(
                        "Existing in base (or given) keypair is wrong. What the hell???"
                    );
                }
                pubKeys.splice(index, 1);
                privKeys.splice(index, 1);
            }
            pubKeys.push(request.publicRsaKey);
            privKeys.push(request.privateRsaKey);
            await chrome.storage.local.set({
                publicRsaKey: pubKeys,
                privateRsaKey: privKeys
            });
            return true;
        }
        case "get_settings":
            return await chrome.storage.local.get({popupDialogs: true});
        case "set":
            await chrome.storage.local.set(request.data);
            return true;
        case "reload":
            try {
                await chrome.tabs.reload(request.tabId);
            } catch (e) {}
            return true;
        case "set_for_tab":
            await chrome.storage.session.set({
                [String(request.tabId)]: request.data
            });
            return true;
        case "get_for_tab": {
            const key = String(request.tabId);
            const result = await chrome.storage.session.get({
                [key]: {}
            });
            return result[key];
        }
        case "get_all_data":
            return await chrome.storage.local.get();
        case "set_all_data":
            await chrome.storage.local.clear();
            await chrome.storage.local.set(request.data);
            return true;
        default:
            throw new Error("Unknown action: " + request.action);
    }
}


const popupDialogs_checkbox = document.getElementById("popupDialogs_checkbox");

let showDialogs = false;
serviceMessage({action: "get_settings"})
    .then(response => {
        console.log(response);
        showDialogs = response.popupDialogs;
        popupDialogs_checkbox.checked = response.popupDialogs;
    },
);

popupDialogs_checkbox.onchange = () => {
    serviceMessage({action: "set",
        data: {popupDialogs: popupDialogs_checkbox.checked}
    });
    console.log("changed setting");
    showDialogs = popupDialogs_checkbox.checked;
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.update(tabs[0].id, {url: tabs[0].url});
})};

function alert_there(msg) {
    try {if (showDialogs) {
        alert_there(msg);
    }} catch(err) {}
}

function prompt_there(msg, dflt) {
    if (showDialogs) {
        try {return prompt(msg, dflt);} catch(err) {return "";}
    }
    console.log("Error. Need some text but dialogs are turned off.");
    return "";
}

function confirm_there(msg) {
    console.log("confirm?", showDialogs);
    if (showDialogs) {
        try {return confirm(msg);} catch(err) {return true;}
    }
    return true;
}

const pub_key_label = document.getElementById("pub_key_label");
const pub_key_button = document.getElementById("pub_key_button");
const version_label = document.getElementById("version_label");
version_label.textContent = "Версия " + chrome.runtime.getManifest().version;

const export_button = document.getElementById("export_button");
export_button.onclick = async () => {
    if (!confirm_there("Вы уверены, что хотите выгрузить все данные? На текущий момент, ваш приватный ключ никак не зашифрован (это будет изменено в будущем обновлении).")) {
        return;
    }
    let data = await serviceMessage({action: "get_all_data"});
    let blb = new Blob([JSON.stringify(data, null, 4)], {type: "text/plain"});
    let fake_link = document.createElement("a");
    fake_link.href = URL.createObjectURL(blb);
    fake_link.download = "vk-crypto-export.json";
    fake_link.click();
    URL.revokeObjectURL(fake_link.href);
    fake_link.remove();
}

const import_button = document.getElementById("import_button");
import_button.onclick = async () => {
    let fake_input = document.createElement("input");
    fake_input.type = "file";
    fake_input.accept = ".json";
    fake_input.addEventListener("change", () => {
        let file = fake_input.files[0];
        if (!file) return;
        let reader = new FileReader();
        reader.onload = async () => {
            let data_string = reader.result;
            fake_input.remove();
            if (!confirm_there("Вы уверены что хотите загрузить новые данные? Старые данные будут удалены (merge будет добавлен скоро). Это действие нельзя отменить.")) {return;}
            try {
                let data_object = JSON.parse(data_string);
                await serviceMessage({action: "set_all_data", data: data_object});
                alert_there("Данные успешно загружены.");
                location.reload();
            } catch (err) {
                alert_there("Ошибка. Формат сейва нарушен.");
            }
        };
        reader.readAsText(file);
    });
    fake_input.click();
}


serviceMessage({action: "get_public_rsa_key"})
    .then(response => {
        console.log("Received: ", response);
        if (response["result"] == undefined) {
            pub_key_label.textContent = "Не сгенерирован."
            pub_key_label.style.color = "red";
            pub_key_label.title = pub_key_button.title = "Вам нужно сгенерировать ключ для работы расширения."
            return;
        }
        pub_key_label.textContent = "..." + response["result"].substring(50, 70) + "...";
        pub_key_button.onclick = () => {
            navigator.clipboard.writeText(response["result"]);
        }
    },
);
